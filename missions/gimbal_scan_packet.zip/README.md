# Gimbal scan packet

Coordinates use the supplied common WGS84-derived ENU map frame, in metres. Longitude and latitude are degrees. Aircraft altitude is relative to the map origin.

Each station holds the aircraft fixed; legs move the optical-axis ground target, not the aircraft. start_s is relative to simultaneous takeoff. Ground speed and duration are nominal flat-ground values. Rapid repoints are not timed in simulation.

task_block_id groups the lower-house remainder under one owner. No-search holes remain excluded; this is one logical task, not a filled polygon.

Camera frame, focal ratio and SDK zoom require physical calibration. Recovery must preserve command_id and the original checkpoint; do not automatically RTL for a recoverable communication or gimbal interruption.
